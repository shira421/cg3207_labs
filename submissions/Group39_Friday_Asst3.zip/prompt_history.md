# Task 4 - Six-step prompt sequence

Status: planned prompts, recorded at the user's request. These are not a claim that all six steps were executed or that they generated the existing HTML. Keep actual responses and revisions when using them.

### Step 1 — Create the HTML using the RTL

> I have an existing radix-2 Booth signed multiplier in Verilog, attached below. Help me create a single-file HTML/CSS/JavaScript visualisation matching this implementation. First identify its registers, widths, decision rules, shifting behaviour and iteration count. Then build an interactive learning tool with signed operand entry, Step, Run, Pause and Reset controls, register displays, operation explanations and a trace table. Use BigInt for accurate 32-bit operands. Clearly distinguish the initial state from computation iterations.

### Step 2 — Check correspondence with the RTL

> Compare the generated HTML against my Verilog implementation. Check register widths, sign extension, the `{Q[0], Qminus1}` decision rules, arithmetic right shift, product extraction and termination after exactly W iterations. Explain any differences between the visualisation’s initial state and the RTL’s first accepting clock edge. Correct any mismatches you find.

### Step 3 — Make register movement easier to understand

> Improve the visual explanation for a beginner. Highlight the two decision bits before each iteration. Show A before and after the add/subtract operation, followed by the combined arithmetic right shift. Clearly indicate the sign bit being copied, A[0] moving into Q’s highest bit, and Q[0] moving into Qminus1. Keep one Step click equal to one complete computation iteration.

### Step 4 — Compare the worked example

> Show the complete register trace for 4-bit −3 × 5, including the initial state, decision pair, operation, A before shifting, and A/Q/Qminus1 after shifting. Confirm that four iterations produce 11110001, representing −15. If I supply a Vivado trace, compare each iteration against it.

### Step 5 — Verify arithmetic and corner cases

> Test the HTML model using all 256 signed operand combinations at 4-bit width. Also test 32-bit boundary cases, including zero, −1, the minimum and maximum signed values, and minimum-negative × −1. Compare the full 2W-bit product against a BigInt reference calculation. Report which tests you actually executed, the results, and any limitations. Fix any errors found.

### Step 6 — Check usability and package the final file

> Check Step, Run, Pause and Reset, invalid operand handling, changing widths, restarting with new operands, and stopping after completion. Make long 32-bit values readable without overflowing the layout. Keep everything in one offline HTML file with no external dependencies. Provide the final file and a concise record of changes and checks actually performed.
